$(function () {
    // 定义变量，用于保存登录的用户信息
    let userinfo = ""
    // 新建一个定时器：用于自动获取数据
    let timeId

    // 按钮功能

    // 显示登录功能
    $(".login").on("click", function () {
        $(".auth").show()
        $(".loginForm").addClass("active")
    })

    // 登录
    $(".loginForm>.submit").on("click", function () {
        // 获取用户名和密码
        $username = $(this).siblings("[name='username']")
        $password = $(this).siblings("[name='password']")
        // val是取input值,trim()去除两边的空格
        let username = $username.val().trim()
        let password = $password.val().trim()

        // 验证用户名和密码
        if (username.length == 0) {
            $username.val("")
            $username.attr("placeholder", "请输入用户名")
            // 获取焦点
            $username.focus()
            return
        }

        if (password.length == 0) {
            $password.val("")
            $password.attr("placeholder", "请输入密码")
            $password.focus()
            return
        }

        // ajax提交数据：json格式
        $.post("/login", `{"username":"${username}","password":"${password}"}`
            , function (data, success) {
                // json格式化转化
                data = JSON.parse(data)

                // 验证
                if (!data.status) {
                    // 没有拿到用户信息：用户名不存在
                    alert(data.info)
                    $username.val("")
                    $password.val("")
                    return
                }

                // 将用户信息存储到用户变量中
                userinfo = data.info

                // 增加当前登录时间（js的时间戳默认是毫秒级别的）
                userinfo.loginTime = Math.floor(Date.now() / 1000)
                // 增加最后一次获取消息的时间：默认为当前时间
                userinfo.LastGetTime = userinfo.loginTime

                // 显示登录信息：替换登录和注册表单
                $(".auth").hide()
                $(".status").html(`欢迎 ${userinfo.Username} 登录，你本次登录的时间为：${new Date(parseInt(userinfo.loginTime) * 1000).toLocaleString().replace(/:\d{1,2}$/, ' ')}。<button class="logout">退出</button>`)

                // 启动自动获取消息：1s一次
                timeId = setInterval(GetNewMsg, 1000)
            })
    })

    // 显示注册功能
    $(".register").on("click", function () {
        $(".auth").show()
        $(".regForm").addClass("active")
    })

    // 注册提交
    $(".regForm>.submit").on("click", function () {
        // 获取数据
        $username = $(this).siblings("[name='username']")
        $password = $(this).siblings("[name='password']")
        $confirm = $(this).siblings("[name='confirmPass']")
        let username = $username.val().trim()
        let password = $password.val().trim()
        let confirm = $confirm.val().trim()

        // 基本验证
        if (username.length == 0 || username.length < 6 || username.length > 15) {
            $username.val("")
            $username.attr("placeholder", "请输入6-15位正确的用户名")
            $username.focus()
            return
        }

        if (password.length == 0 || password.length < 5) {
            $password.val("")
            $password.attr("placeholder", "请输入5位以上的密码")
            $password.focus()
            return
        }

        if (password != confirm) {
            $confirm.val("")
            $confirm.attr("placeholder", "两次密码必须一致")
            $confirm.focus()
            return
        }

        // 提交数据
        $.post("/register", `{"username":"${username}","password":"${password}","confirm":"${confirm}"}`
            , function (data, success) {
                // 处理json格式数据：JSON.parse()
                data = JSON.parse(data)
                if (data.status) {
                    // 注册成功
                    alert("注册成功")
                    $(".login").click()
                } else {
                    // 注册失败
                    alert(data.info)
                    $username.val("")
                    $password.val("")
                    $confirm.val("")
                }
            })
    })

    // 返回主页：各自功能
    $(".back").on("click", function () {
        $(".auth").hide()
        $(this).parent().removeClass("active")
    })

    // 发送消息
    $(".send").on("click", function () {
        // 验证用户是否登录
        if (userinfo == "") {
            // 没有用户信息：没有登录
            alert("请先登录")
            $(".login").click()
            return
        }

        // 获取用户输入的数据
        $msg = $("#msg")
        let msg = $msg.val().trim()

        // 数据安全
        if (msg.length == 0) {
            $msg.val("")        // 清空
            return
        }

        // 写入到聊天记录

        // 发送给服务器
        $.post("/send", `{"UserId":"${userinfo.UserId}","Msg":"${msg}"}`,
            function (data, success) {

                // json格式数据转换
                data = JSON.parse(data)

                // 失败
                if (!data.status) {
                    alert(data.info)
                    return
                }

                // 清空写的消息内容
                $msg.val("")

                // 成功：发布消息，并清空
                $(".content").append(`
                    <div class="msg">
            <div class="msg-info">
                <span class="user-name">${userinfo.Username}</span>发布于
                <span class="time">${new Date().toLocaleString().replace(/:\d{1,2}$/, ' ')}</span>
            </div>
            <div class="detail">
                <span>
                    ${msg}
                </span>
            </div>
        </div>
                `)

            })
    })

    // 获取最新消息
    const GetNewMsg = function () {
        // 验证用户是否登录
        if (userinfo == "") return

        // 不断获取最新消息
        $.post("/msg",
            `{"UserId":"${userinfo.UserId}","LastGetTime":"${userinfo.LastGetTime}"}`,
            function (data, success) {
                // json转换
                data = JSON.parse(data)

                if (!data.status) {
                    // 获取消息失败
                    return
                }

                // 批量构造数据展示
                data.info.forEach(function (item) {
                    $(".content").append(`
                    <div class="msg">
            <div class="msg-info">
                <span class="user-name">${item.Username}</span>发布于
                <span class="time">${new Date(item.SendTime).toLocaleString().replace(/:\d{1,2}$/, ' ')}</span>
            </div>
            <div class="detail">
                <span>
                    ${item.Msg}
                </span>
            </div>
        </div>
                `)
                })

                // 更新获取时间为当下
                userinfo.LastGetTime = Math.floor(Date.now() / 1000)
            })
    }
})

